from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
import os,sys
from converter import convert_ui
convert_ui("chat.ui")
from chat import *
import socket

hote="localhost"
port=12801

connexion_avec_serveur=socket.socket (socket.AF_INET, socket.SOCK_STREAM)
connexion_avec_serveur.connect((hote, port))
print ("Connexion établie avec le serveur sur le port {}".format (port))


class chatsnap(QWidget,Ui_fenetre):
    def __init__(self, parent=None):
        QWidget.__init__(self)
        self.setupUi(parent)
        # self.pushButton.setText("test");
        self.pushButton_2.clicked.connect(self.envoie)
    def envoie(self):
            entree=self.lineEdit.text()
            print(entree)
            # msg.append(entree)
            # self.listWidget.addItem(f"(vous) {entree}")
            self.ajout("vous",entree)
            print("#####")
            if entree=="fin":
                connexion_avec_serveur.send(entree.encode())
                self.ajout("serveur",connexion_avec_serveur.recv(1024).decode())
                connexion_avec_serveur.close()
            else:
                connexion_avec_serveur.send(entree.encode())
                self.ajout("serveur",connexion_avec_serveur.recv(1024).decode())

    def ajout(self,personne,message):
        self.listWidget.addItem(f"({personne}) {message}")
        print(f"{message} → ajouté({personne})")
    def test_entree():
        '''renvoie l'entrée s'il y en a une dans la demi seconde ou false sinon'''
        pass
def main(args):
    a=QApplication(args)
    f=QWidget()
    c=chatsnap(f)
    f.show()
    r=a.exec_()
    return r,c

if __name__=="__main__":
    chat=main(sys.argv)[1]

# print ("Fermeture de la connexion ")

