from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
import os,sys
from converter import convert_ui
convert_ui("chat.ui")
from chat import *

class calculatrice(QWidget,Ui_fenetre):
    def __init__(self, parent=None):
        QWidget.__init__(self)
        self.setupUi(parent)
        # self.pushButton.setText("test");
        self.pushButton_2.clicked.connect(self.affiche)
    def affiche(self):
        try:
            entree=self.lineEdit.text()
            print(entree)
            self.listWidget.addItem(f"(vous) {entree}")
        except:
            pass
    def reception(self,personne,message):
        self.listWidget.addItem(f"({personne}) {message}")
def main(args):
    a=QApplication(args)
    f=QWidget()
    c=calculatrice(f)
    f.show()
    r=a.exec_()
    return r
if __name__=="__main__":
    main(sys.argv)