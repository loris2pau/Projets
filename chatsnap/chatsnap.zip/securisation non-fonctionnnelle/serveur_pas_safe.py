#definition d'un serveur réseau gérant un système de CHAT simplifié.
#utilise les threads pour gérer les connexions clientes en parallèle.
#chemin_maison='C:/Users/cleme/Bureau/clement/travail/tle/nsi/cours/reseaux/projet'
HOST=''
PORT=40000 #nombre entre 1024 et 65535
import socket,sys,threading,unidecode
from chiffrement_symetrique import *
from chiffrement_assymetrique import *
CHIFFREMENT_SERVEUR=Symetrique()
class ThreadClient(threading.Thread):
    '''dérivation d'un objet thread pour gérer la connexion avec un client'''

    def __init__(self,conn):
        threading.Thread.__init__(self)
        self.connexion=conn
        self.ouvert=True
        self.cle_envoyee=False
        self.chiffrement_serveur=CHIFFREMENT_SERVEUR
        self.cle_pb_client=None

    def run(self):
        #dialogue avec le client
        nom=self.getName() #chaque thread possède un nom
        while self.ouvert:
            msgClient=traduit_en_utf_8(self.connexion.recv(1024))
            if self.cle_pb_client==None:
                self.recoit_cle_publique(msgClient)
                self.envoie_cle_symetrique()

            else:
                #print(msgClient.upper())
                if msgClient.upper()=='FIN' or msgClient=="":
                    self.ouvert=False
                if self.ouvert:
                    message=f"{nom}>{msgClient}"
                    print(message)
                #on fait suivre le message à tous les clients (INITALEMENT PUIS AU CLIENT DÉSIRÉ)
                for client in conn_client:
                    if client!=nom:#on ne renvoie pas à l'émetteur
                        conn_client[client].send(bytes(message,'utf-8'))
        #fermeture de la connexion
        self.connexion.close()#coupe la connexion côté serveur
        del conn_client[nom]#supprime l'entrée de la connexion dans le dictionnaire
        print(f"Client {nom} déconnecté")
        #le thread se termine ici

    def recoit_cle_publique(self,msgClient):
        """prend en paramètre un message client de la forme 'C.P.B.(' et modifie l'attribut cle_pb_client par le tuple de la chaine de caractère"""
        assert(msgClient[:7]=='C.P.B.('),"le msgClient n'est pas une clé publique"#je vérifie que je recoit une clé publique
        e=""#j'initialise le e et le n de la cle publique
        virgule_passee=False#variable qui va servir à savoir si on est tjr dans le e ou si on est passé dans le n
        n=""
        for i in range(7,len(msgClient)):#commence à 7 car C.P.B.( au début
            lettre=msgClient[i]
            if lettre==',':#si je passe la virgule
                virgule_passee=True
            if not(virgule_passee) and est_un_chiffre(lettre):#si la virgule n'est pas passée et que ma lettre est aussi un chiffre alors, je suis dans le e et j'ajoute mon chiffre au e
                e+=lettre
            if virgule_passee and est_un_chiffre(lettre):# si la virgule est passée et que ma lettre est un chiffre alors je suis dans le n et j'ajoute ma lettre à n
                n+=lettre
        print("clé publique =",e,n)
        try :
            e,n=int(e),int(n)
            self.cle_pb_client=(e,n)
            print("la cle publique est reçue")
        except ValueError :
            print(" e ou n ne peut pas être convertit en entier")

    def envoie_cle_symetrique(self):
        """envoie la cle de chiffrement symetrique au client au format C.C.S.("""
        client=self.getName()#je récupère le nom du client auquel je dois adressé la clé
        cle=traduit_en_utf_8(self.chiffrement_serveur.key)#je la traduit en utf-8
        print("cle symétrique decodee = ",cle)
        assert(type(self.cle_pb_client)!=None),"la clé publique du client est None"
        cle_codee=chiffre_avec_cle_pb(self.cle_pb_client,cle)#et je la code avec la cle publique du client
        msg_cle_codee="C.C.S.("+cle_codee #j'élabore le message pour que le client sache que ce qui suit est la Clé de Chiffrement Symétrique codee avec la cle publique
        print("cle symétrique codee enoyée",msg_cle_codee)
        conn_client[client].send(traduit_en_bytes(msg_cle_codee))#j'envoie le message codé et traduit en bytes
        print("la clé de chiffrement symétrique a été envoyée au client")

def est_un_chiffre(lettre):
    """renvoie true si la lettre en paramètre est un chiffrre false sinon"""
    return lettre in ['0','1','2','3','4','5','6','7','8','9']




##

#initialisation du serveur - mise en place du serveur :
mySocket=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
try:
    mySocket.bind((HOST,PORT))
    mySocket.listen(5)
except socket.error :
    print("la liaison du socket à l'adresse choisie a échoué")
    sys.exit()
print("serveur prêt, en attente de requêtes ...")
#attente et prise en charge des connexions demandées par les clients :
conn_client={}#dictionnire des connexions clients
while True:
    connexion,adresse=mySocket.accept()
    #cree un nouvel objet thread pour gérer la connexion
    th=ThreadClient(connexion)
    th.start()
    #mémoriser la connexion dans le dictionnaire
    it=th.getName()
    conn_client[it]=connexion
    print(f"client {it} connecté, adresse IP {adresse[0]}, port {adresse[1]}")
    #connexion.send(bytes(unidecode.unidecode("vous êtes connecté : envoyez vos messages."),'utf-8'))