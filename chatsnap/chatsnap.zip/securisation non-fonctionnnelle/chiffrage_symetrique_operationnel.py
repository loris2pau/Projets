
#chiffrement symétrique
from cryptography.fernet import Fernet

class Symetrique:
    def __init__(self,cle=None):
        self.cle=Fernet.generate_key()
        self.f=Fernet(self.cle)

    def encrypte(self,message):
        return self.f.encrypt(bytes(message,'utf-8'))

    def decrypte(self,message):
        return self.f.decrypt(message)

if __name__=='__main__':
    message='hello'
    chiffrement=Symetrique()
    code=chiffrement.encrypte(message)
    print(code)
    print(chiffrement.decrypte(code))