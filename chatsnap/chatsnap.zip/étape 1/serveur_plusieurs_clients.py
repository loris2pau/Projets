#definition d'un serveur réseau gérant un système de CHAT simplifié.
#utilise les threads pour gérer les connexions clientes en parallèle.
HOST=''
PORT=40000 #nombre entre 1024 et 65535
import socket,sys,threading,unidecode
class ThreadClient(threading.Thread):
    '''dérivation d'un objet thread pour gérer la connexion avec un client'''
    def __init__(self,conn):
        threading.Thread.__init__(self)
        self.connexion=conn
        self.ouvert=True

    def run(self):
        #dialogue avec le client
        nom=self.getName() #chaque thread possède un nom
        while self.ouvert:
            msgClient=str(self.connexion.recv(1024))#on recoit le message du client
            #print(msgClient[2:-1].upper())
            if msgClient[2:-1].upper()=='FIN' or msgClient=="":
                self.ouvert=False#on regarde si le client veut continuer la conversation
            if self.ouvert:
                message=f"{nom}>{msgClient[1:]}"
                print(message)
            #on fait suivre le message à tous les clients (INITALEMENT PUIS AU CLIENT DÉSIRÉ)
            for client in conn_client:#on envoie le message à tout le monde mais
                if client!=nom:#on ne renvoie pas à l'émetteur
                    conn_client[client].send(bytes(message,'utf-8'))
        #fermeture de la connexion
        self.connexion.close()#coupe la connexion côté serveur
        del conn_client[nom]#supprime l'entrée de la connexion dans le dictionnaire
        print(f"Client {nom} déconnecté")
        #le thread se termine ici
        

#initialisation du serveur - mise en place du serveur :
mySocket=socket.socket(socket.AF_INET,socket.SOCK_STREAM)#création du socket pour connecter serveur et machine
try:
    mySocket.bind((HOST,PORT))#on connecte le socket sur le port de la machine
except socket.error :
    print("la liaison du socket à l'adresse choisie a échoué")
    sys.exit()
print("serveur prêt, en attente de requêtes ...")
#attente et prise en charge des connexions demandées par les clients :
conn_client={}#dictionnire des connexions clients
while True:
    mySocket.listen(5)#on attent les connexions
    connexion,adresse=mySocket.accept()#et on les accepte
    #cree un nouvel objet thread pour gérer la connexion
    th=ThreadClient(connexion)#pour chaque client, on crée un thread qui va nous permettre de gérer chaque client indépendamment des autres
    th.start()
    #mémoriser la connexion dans le dictionnaire
    it=th.getName()
    conn_client[it]=connexion
    print(f"client {it} connecté, adresse IP {adresse[0]}, port {adresse[1]}")
    connexion.send(bytes(unidecode.unidecode("vous êtes connecté : envoyez vos messages."),'utf-8'))