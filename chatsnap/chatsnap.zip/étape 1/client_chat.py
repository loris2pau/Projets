#définition d'un client réseau gérant en parallèle l'émission et la réception des messages (utilisation de 2 THREADS)
HOST='localhost'#adresse du serveur
PORT=40000
import socket,sys,threading,unidecode
class ThreadReception(threading.Thread):
    """objet gérant la réception des messages"""
    def __init__(self,conn):
        threading.Thread.__init__(self)
        self.connexion=conn
        self.ouvert=True

    def run(self):
        while self.ouvert:
            message_recu=str(self.connexion.recv(1024))#on reçoit le message et on le convertit en str pour une meilleure utilisation
            print("*"+message_recu[1:-1]+"*")
            if message_recu=='' or message_recu.upper()=='FIN':#si la conversation se termine
                self.ouvert=False
        #le thread <reception> se termine ici
        #on force la fermeture du thread <émission> :
        self.connexion.close()
        th_E._Thread__stop()
        print("Client arrêté et connexion interrompue")

class ThreadEmission(threading.Thread):
    """objet thread gérant l'émission des messages"""
    def __init__(self,conn):
        threading.Thread.__init__(self)
        self.connexion=conn

    def run(self):
        while True:
            message_emis=unidecode.unidecode(input())#on enlève les caractères spéciaux du message à envoyer
            self.connexion.send(bytes(message_emis,'utf-8'))#on le transforme en bytes et on l'envoie





#programme principal- Etablissement de la connexion :
connexion=socket.socket(socket.AF_INET,socket.SOCK_STREAM)#on crée l'objet socket qui va nous permettre de faire communiquer les machines
try :
    connexion.connect((HOST,PORT))#on la connecte au serveur
except socket.error:
    print("la connexion a échoué")
    sys.exit()
print("Connexion établie avec le serveur")
th_E=ThreadEmission(connexion)#et on divise les tâches émission et reception en threads pour éviter que le programme ne reste bloqué en phase d'émission ou en phase de réception
th_R=ThreadReception(connexion)
th_E.start()
th_R.start()
